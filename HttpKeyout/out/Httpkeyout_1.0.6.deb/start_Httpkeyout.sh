#!/bin/bash
export VERSION=1.0.6
export WORKING_DIR=Httpkeyout_1.0.6
export WORKING_FILE=Httpkeyout.py
export BUILD_DATE=2025-09-29T16:18:49+07:00
cd /apps/Httpkeyout_1.0.6
python3 Httpkeyout.py &
