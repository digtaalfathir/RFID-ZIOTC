#!/bin/bash
export VERSION=1.1.0
export WORKING_DIR=Httpkeyout_1.1.0
export WORKING_FILE=Httpkeyout.py
export BUILD_DATE=2025-12-29T08:49:59+07:00
cd /apps/Httpkeyout_1.1.0
python3 Httpkeyout.py &
