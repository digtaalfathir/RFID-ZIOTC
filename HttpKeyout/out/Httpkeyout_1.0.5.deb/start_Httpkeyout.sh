#!/bin/bash
export VERSION=1.0.5
export WORKING_DIR=Httpkeyout_1.0.5
export WORKING_FILE=Httpkeyout.py
export BUILD_DATE=2025-09-29T16:08:57+07:00
cd /apps/Httpkeyout_1.0.5
python3 Httpkeyout.py &
