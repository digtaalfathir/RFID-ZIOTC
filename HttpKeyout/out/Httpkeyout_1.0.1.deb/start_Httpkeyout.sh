#!/bin/bash
export VERSION=1.0.1
export WORKING_DIR=Httpkeyout_1.0.1
export WORKING_FILE=Httpkeyout.py
export BUILD_DATE=2025-08-18T15:55:06+07:00
cd /apps/Httpkeyout_1.0.1
python3 Httpkeyout.py &
