#!/bin/bash
export VERSION=1.1.1
export WORKING_DIR=Httpkeyout_1.1.1
export WORKING_FILE=Httpkeyout.py
export BUILD_DATE=2025-12-29T08:50:43+07:00
cd /apps/Httpkeyout_1.1.1
python3 Httpkeyout.py &
