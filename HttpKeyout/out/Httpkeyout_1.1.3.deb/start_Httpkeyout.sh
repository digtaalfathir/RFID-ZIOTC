#!/bin/bash
export VERSION=1.1.3
export WORKING_DIR=Httpkeyout_1.1.3
export WORKING_FILE=Httpkeyout.py
export BUILD_DATE=2026-06-04T08:16:43+07:00
cd /apps/Httpkeyout_1.1.3
python3 Httpkeyout.py &
