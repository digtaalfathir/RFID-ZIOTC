#!/bin/bash
export VERSION=1.0.2
export WORKING_DIR=Httpkeyout_1.0.2
export WORKING_FILE=Httpkeyout.py
export BUILD_DATE=2025-08-18T16:03:18+07:00
cd /apps/Httpkeyout_1.0.2
python3 Httpkeyout.py &
