#!/bin/bash
export VERSION=1.0.4
export WORKING_DIR=Httpkeyout_1.0.4
export WORKING_FILE=Httpkeyout.py
export BUILD_DATE=2025-09-29T15:46:23+07:00
cd /apps/Httpkeyout_1.0.4
python3 Httpkeyout.py &
