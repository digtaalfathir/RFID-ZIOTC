#!/bin/bash
export VERSION=1.0.0
export WORKING_DIR=Httpkeyout_1.0.0
export WORKING_FILE=Httpkeyout.py
export BUILD_DATE=2025-08-07T09:36:03+07:00
cd /apps/Httpkeyout_1.0.0
python3 Httpkeyout.py &
