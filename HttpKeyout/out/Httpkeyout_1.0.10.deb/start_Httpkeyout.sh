#!/bin/bash
export VERSION=1.0.10
export WORKING_DIR=Httpkeyout_1.0.10
export WORKING_FILE=Httpkeyout.py
export BUILD_DATE=2025-10-28T14:35:42+07:00
cd /apps/Httpkeyout_1.0.10
python3 Httpkeyout.py &
