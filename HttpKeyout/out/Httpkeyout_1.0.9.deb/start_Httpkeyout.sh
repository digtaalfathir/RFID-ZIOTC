#!/bin/bash
export VERSION=1.0.9
export WORKING_DIR=Httpkeyout_1.0.9
export WORKING_FILE=Httpkeyout.py
export BUILD_DATE=2025-10-28T14:16:14+07:00
cd /apps/Httpkeyout_1.0.9
python3 Httpkeyout.py &
