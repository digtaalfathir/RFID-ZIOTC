#!/bin/bash
export VERSION=1.0.8
export WORKING_DIR=Httpkeyout_1.0.8
export WORKING_FILE=Httpkeyout.py
export BUILD_DATE=2025-10-20T17:34:53+07:00
cd /apps/Httpkeyout_1.0.8
python3 Httpkeyout.py &
