import websocket
import ssl
import json
import threading
import time
import requests

# Konfigurasi
READER_WS_URL = "wss://192.168.123.10:443"
VERIFY_CERT = False

POST_URL = "http://your-flask-server-ip:5000/rfid"  # Ganti sesuai IP/port server Flask

# Buffer untuk data RFID
buffer_lock = threading.Lock()
rfid_buffer = []  # List of dict: {idHex, antenna, timestamp}
last_sent_time = 0
send_interval = 5  # dalam detik

reader_id = "FX96006A6F01"

# Fungsi untuk mengirim data buffered
def flush_buffer():
    global last_sent_time
    while True:
        time.sleep(1)
        now = time.time()
        with buffer_lock:
            if rfid_buffer and now - last_sent_time >= send_interval:
                unique_tags = {}
                for item in rfid_buffer:
                    key = item["idHex"]
                    if key not in unique_tags:
                        unique_tags[key] = item  # ambil data pertama yang muncul saja

                payload = {
                    "reader_id": reader_id,
                    "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                    "idHex": list(unique_tags.keys()),
                    "antennas": [item["antenna"] for item in unique_tags.values()],
                }

                try:
                    response = requests.post(POST_URL, json=payload)
                    print("📤 Data POST:", json.dumps(payload))
                    print("📥 Respon:", response.status_code, response.text)
                except Exception as e:
                    print("❌ Gagal POST:", str(e))

                # Kosongkan buffer & perbarui waktu
                rfid_buffer.clear()
                last_sent_time = now

# Callback pesan masuk dari WebSocket
def on_message(ws, message):
    global rfid_buffer
    try:
        data = json.loads(message)
        # Validasi data
        if "idHex" not in data or "antenna" not in data:
            return

        id_hex = data["idHex"]
        antenna = data["antenna"]
        timestamp = data.get("timestamp", time.strftime("%Y-%m-%dT%H:%M:%S%z"))

        with buffer_lock:
            # Hindari duplicate persis
            if not any(d["idHex"] == id_hex for d in rfid_buffer):
                rfid_buffer.append({
                    "idHex": id_hex,
                    "antenna": antenna,
                    "timestamp": timestamp
                })

        # Keyboard output hanya untuk antenna 8
        if antenna == 8:
            try:
                # Format ke keyboard (misalnya print dulu sebagai simulasi)
                print("⌨️ Kirim ke keyboard:", id_hex)
                # Contoh: ziotcObject.send_next_msg(pyziotc.MSG_OUT_DATA, bytearray((id_hex + "\n").encode('utf-8')))
            except Exception as e:
                print("❌ Gagal kirim ke keyboard:", str(e))

    except Exception as e:
        print("❌ Gagal parsing message:", str(e))

def on_open(ws):
    print("🔗 WebSocket terbuka")

def on_close(ws, close_status_code, close_msg):
    print("🔌 WebSocket tertutup:", close_status_code, close_msg)

def on_error(ws, error):
    print("⚠️ WebSocket error:", error)

# Thread WebSocket client
def run_ws():
    ws = websocket.WebSocketApp(
        READER_WS_URL,
        on_message=on_message,
        on_open=on_open,
        on_close=on_close,
        on_error=on_error
    )
    if READER_WS_URL.startswith("wss://"):
        ws.run_forever(sslopt={"cert_reqs": ssl.CERT_NONE if not VERIFY_CERT else ssl.CERT_REQUIRED})
    else:
        ws.run_forever()

if __name__ == "__main__":
    # Jalankan thread WebSocket
    threading.Thread(target=run_ws, daemon=True).start()
    # Jalankan thread untuk flush buffer per 5 detik
    threading.Thread(target=flush_buffer, daemon=True).start()

    # Biar program tetap hidup
    while True:
        time.sleep(1)
