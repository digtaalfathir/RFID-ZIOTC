#!/bin/bash
export VERSION=1.2.2
export WORKING_DIR=Keyout_1.2.2
export WORKING_FILE=Keyout.py
export BUILD_DATE=2025-07-23T10:53:45+07:00
cd /apps/Keyout_1.2.2
python3 Keyout.py &
