#!/bin/bash
export VERSION=1.1.3
export WORKING_DIR=Keyout_1.1.3
export WORKING_FILE=Keyout.py
export BUILD_DATE=2025-07-21T15:41:01+07:00
cd /apps/Keyout_1.1.3
python3 Keyout.py &
