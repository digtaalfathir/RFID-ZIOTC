#!/bin/bash
export VERSION=1.2.3
export WORKING_DIR=Keyout_1.2.3
export WORKING_FILE=Keyout.py
export BUILD_DATE=2025-07-23T10:58:32+07:00
cd /apps/Keyout_1.2.3
python3 Keyout.py &
