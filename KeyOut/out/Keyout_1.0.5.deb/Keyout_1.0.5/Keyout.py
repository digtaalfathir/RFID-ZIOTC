import pyziotc
import json
import os
import traceback
import time
import signal
import http.client
from Logger import Logger
from RestAPI import RestAPI

DEBUG_SERVER = "192.168.13.140"
DEBUG_PORT = 40514
LOG_ONLY_TO_CONSOLE = False
REST_API_RETRY_COUNT = 3
BATCH_WINDOW = 5  # Detik

Stop = False
ziotcObject = pyziotc.Ziotc()
logger = Logger(DEBUG_SERVER, DEBUG_PORT, LOG_ONLY_TO_CONSOLE)
restAPI = RestAPI(logger, REST_API_RETRY_COUNT, ziotcObject)

# Buffer batch tag
tag_batch = []
last_batch_time = 0
batch_metadata = {"reader_id": "", "antenna": "", "timestamp": ""}

def sigHandler(signum, frame):
    global Stop
    Stop = True

def post_to_flask(payload):
    try:
        json_data = json.dumps(payload)
        conn = http.client.HTTPConnection("192.168.123.1", 5000, timeout=2)
        headers = {"Content-type": "application/json"}
        conn.request("POST", "/rfid", json_data, headers)
        res = conn.getresponse()
        conn.close()
        logger.debug(f"POST to Flask OK: {res.status}")
    except Exception as e:
        logger.err(f"HTTP POST failed: {str(e)}")

def flush_batch():
    global tag_batch, batch_metadata
    if tag_batch:
        payload = {
            "reader_id": batch_metadata["reader_id"],
            "antenna": batch_metadata["antenna"],
            "idHex": tag_batch,
            "timestamp": batch_metadata["timestamp"]
        }
        post_to_flask(payload)
        logger.info(f"Flushed {len(tag_batch)} tags: {payload}")
        tag_batch = []  # Clear buffer

def process_tag(msg_in):
    global tag_batch, last_batch_time, batch_metadata

    try:
        msg_in_json = json.loads(msg_in)
        data = msg_in_json.get("data", {})
        timestamp = msg_in_json.get("timestamp", "")
        id_hex = data.get("idHex", "")

        if not id_hex:
            logger.warn("No idHex found in data.")
            return

        now = time.time()

        # Jika batch kosong atau waktu sudah lewat dari window, flush dulu
        if not tag_batch or (now - last_batch_time > BATCH_WINDOW):
            flush_batch()
            last_batch_time = now
            batch_metadata = {
                "reader_id": data.get("hostName", ""),
                "antenna": str(data.get("antenna", "")),
                "timestamp": timestamp
            }

        # Tambahkan tag ke batch jika belum ada
        if id_hex not in tag_batch:
            tag_batch.append(id_hex)

    except Exception as e:
        logger.err(f"Failed to process tag: {str(e)}")

# === Main Loop ===
signal.signal(signal.SIGINT, sigHandler)

logger.debug("System Started: PID " + str(os.getpid()))
logger.debug("Reader Version: " + restAPI.getReaderVersion())
logger.debug("Reader Serial Number: " + restAPI.getReaderSerial())
logger.debug("Script Version: " + str(os.getenv("VERSION")))

ziotcObject.reg_new_msg_callback(lambda t, m: process_tag(m) if t == pyziotc.MSG_IN_JSON else None)
restAPI.startInventory()

try:
    while not Stop:
        time.sleep(1)
        if tag_batch and (time.time() - last_batch_time > BATCH_WINDOW):
            flush_batch()
finally:
    restAPI.stopInventory()
    flush_batch()
    logger.info("Stopped")
