#!/bin/bash
export VERSION=1.0.4
export WORKING_DIR=Keyout_1.0.4
export WORKING_FILE=Keyout.py
export BUILD_DATE=2025-07-21T12:30:24+07:00
cd /apps/Keyout_1.0.4
python3 Keyout.py &
