#!/bin/bash
export VERSION=1.0.2
export WORKING_DIR=Keyout_1.0.2
export WORKING_FILE=Keyout.py
export BUILD_DATE=2025-07-21T12:07:05+07:00
cd /apps/Keyout_1.0.2
python3 Keyout.py &
