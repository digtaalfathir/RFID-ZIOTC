import pyziotc
import json
import os
import traceback
import time
import signal
import http.client
from Logger import Logger
from RestAPI import RestAPI

# === Global Constants ===
DEBUG_SERVER = "192.168.13.140"
DEBUG_PORT = 40514
LOG_ONLY_TO_CONSOLE = False
REST_API_RETRY_COUNT = 3
DUPLICATE_DELAY = 10  # Detik

# === State ===
Stop = False
last_seen_tags = {}  # Dictionary: {idHex: timestamp}
ziotcObject = pyziotc.Ziotc()
logger = Logger(DEBUG_SERVER, DEBUG_PORT, LOG_ONLY_TO_CONSOLE)
restAPI = RestAPI(logger, REST_API_RETRY_COUNT, ziotcObject)

# === Signal Handler ===
def sigHandler(signum, frame):
    global Stop
    Stop = True

# === Callback dari pyziotc ===
def new_msg_callback(msg_type, msg_in):
    if msg_type == pyziotc.MSG_IN_JSON:
        process_tag(msg_in)

# === Kirim ke Flask ===
def post_to_flask(payload):
    try:
        json_data = json.dumps(payload)
        conn = http.client.HTTPConnection("192.168.123.1", 5000, timeout=2)
        headers = {"Content-type": "application/json"}
        conn.request("POST", "/rfid", json_data, headers)
        res = conn.getresponse()
        conn.close()
        logger.debug(f"POST to Flask OK: {res.status}")
    except Exception as e:
        logger.err(f"HTTP POST failed: {str(e)}")

# === Proses tag dari reader ===
def process_tag(msg_in):
    global last_seen_tags

    try:
        msg_in_json = json.loads(msg_in)
        data = msg_in_json.get("data", {})
        timestamp = msg_in_json.get("timestamp", "")

        id_hex = data.get("idHex", "")
        if not id_hex:
            logger.warn("No idHex found in data.")
            return

        # Hindari duplikasi dalam 10 detik
        now = time.time()
        last_seen = last_seen_tags.get(id_hex, 0)
        if now - last_seen < DUPLICATE_DELAY:
            logger.debug(f"Duplicate tag ignored: {id_hex}")
            return
        last_seen_tags[id_hex] = now

        # === Kirim ke keyboard ===
        ziotcObject.send_next_msg(pyziotc.MSG_OUT_DATA, bytearray((id_hex + "\n").encode('utf-8')))
        logger.debug(f"Sent to keyboard: {id_hex}")

        # === Kirim ke Flask ===
        flask_payload = {
            "reader_id": data.get("hostName", ""),
            "antenna": data.get("antenna", ""),
            "idHex": id_hex,
            "timestamp": timestamp
        }
        post_to_flask(flask_payload)

    except Exception as e:
        logger.err(f"Failed to process tag: {str(e)}")

# === Main ===
signal.signal(signal.SIGINT, sigHandler)

logger.debug("System Started: PID " + str(os.getpid()))
logger.debug("Reader Version: " + restAPI.getReaderVersion())
logger.debug("Reader Serial Number: " + restAPI.getReaderSerial())
logger.debug("Script Version: " + str(os.getenv("VERSION")))

ziotcObject.reg_new_msg_callback(new_msg_callback)
restAPI.startInventory()

while not Stop:
    time.sleep(0.2)

restAPI.stopInventory()
logger.info("Stopped")
