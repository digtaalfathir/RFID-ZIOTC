import pyziotc
import json
import os
import traceback
import time
import signal
import websocket  # pip install websocket-client
from Logger import Logger
from RestAPI import RestAPI

# === Global Constants ===
DEBUG_SERVER = "192.168.13.140"
DEBUG_PORT = 40514
LOG_ONLY_TO_CONSOLE = False
WS_SERVER = "ws://192.168.123.1:8765"  # Ganti dengan alamat WebSocket server Anda
DUPLICATE_DELAY = 10  # Detik

# === State ===
Stop = False
ws = None
last_seen_tags = {}
ziotcObject = pyziotc.Ziotc()
logger = Logger(DEBUG_SERVER, DEBUG_PORT, LOG_ONLY_TO_CONSOLE)
restAPI = RestAPI(logger, 3, ziotcObject)

# === Signal Handler ===
def sigHandler(signum, frame):
    global Stop
    Stop = True

# === Callback dari pyziotc ===
def new_msg_callback(msg_type, msg_in):
    if msg_type == pyziotc.MSG_IN_JSON:
        process_tag(msg_in)

# === Kirim ke WebSocket Server ===
def send_to_websocket(payload):
    global ws
    try:
        if ws and ws.sock and ws.sock.connected:
            ws.send(json.dumps(payload))
            logger.debug(f"Sent via WebSocket: {payload}")
        else:
            logger.err("WebSocket not connected.")
    except Exception as e:
        logger.err(f"WebSocket send error: {str(e)}")

# === Proses tag dari reader ===
def process_tag(msg_in):
    global last_seen_tags

    try:
        msg_in_json = json.loads(msg_in)
        data = msg_in_json.get("data", {})
        timestamp = msg_in_json.get("timestamp", "")

        id_hex = data.get("idHex", "")
        if not id_hex:
            logger.warn("No idHex found in data.")
            return

        # Hindari duplikasi dalam 10 detik
        now = time.time()
        last_seen = last_seen_tags.get(id_hex, 0)
        if now - last_seen < DUPLICATE_DELAY:
            logger.debug(f"Duplicate tag ignored: {id_hex}")
            return
        last_seen_tags[id_hex] = now

        # === Kirim ke keyboard ===
        ziotcObject.send_next_msg(pyziotc.MSG_OUT_DATA, bytearray((id_hex + "\n").encode('utf-8')))
        logger.debug(f"Sent to keyboard: {id_hex}")

        # === Kirim ke WebSocket ===
        ws_payload = {
            "reader_id": data.get("hostName", ""),
            "antenna": data.get("antenna", ""),
            "idHex": id_hex,
            "timestamp": timestamp
        }
        send_to_websocket(ws_payload)

    except Exception as e:
        logger.err(f"Failed to process tag: {str(e)}")

# === Inisialisasi WebSocket Connection ===
def connect_ws():
    global ws
    try:
        ws = websocket.create_connection(WS_SERVER, timeout=5)
        logger.debug("WebSocket connected to " + WS_SERVER)
    except Exception as e:
        logger.err(f"WebSocket connection failed: {str(e)}")

# === Main ===
signal.signal(signal.SIGINT, sigHandler)

logger.debug("System Started: PID " + str(os.getpid()))
logger.debug("Reader Version: " + restAPI.getReaderVersion())
logger.debug("Reader Serial Number: " + restAPI.getReaderSerial())
logger.debug("Script Version: " + str(os.getenv("VERSION")))

# Hubungkan ke WebSocket server
connect_ws()

ziotcObject.reg_new_msg_callback(new_msg_callback)
restAPI.startInventory()

while not Stop:
    time.sleep(0.2)

restAPI.stopInventory()
if ws:
    ws.close()
logger.info("Stopped")
